Rdio for XBMC
=============

Rdio for XBMC is an XBMC add-on that allows you to play your [Rdio](http://www.rdio.com) music collection through the [XBMC](http://xbmc.org) media centre.

For information on installing and using this add-on, please visit the [rdio-xbmc wiki](https://github.com/ampedandwired/rdio-xbmc/wiki).
